function setup() {
  createCanvas(400, 200);
  background(0);
}

function draw() {
  fill(255, 165, 0); // Laranja
  textSize(32);
  textAlign(CENTER, CENTER);
  text("Pensamento Computacional", width/2, height/2);
}